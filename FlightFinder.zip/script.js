document.getElementById("flight-search-form")?.addEventListener("submit", function(e) {
  e.preventDefault();
  const from = this.from.value;
  const to = this.to.value;
  const date = this.date.value;
  document.getElementById("results").innerHTML = `
    <h3>Available Flights</h3>
    <ul>
      <li>Flight from ${from} to ${to} on ${date}</li>
    </ul>`;
});